#ifndef _PROC_H_
#define _PROC_H_

int foo_proc_init(void);
void foo_proc_exit(void);

#endif // _PROC_H_
